﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class playerController : MonoBehaviour
{
    // Start is called before the first frame update
    private float movement = 0f;
    private float jumpspeed = 10f;
    private float speed = 10f;
    private Rigidbody2D rigidbody;
    void Start()
    {
        rigidbody = GetComponent<Rigidbody2D>();

    }

    // Update is called once per frame
    void Update()
    {
        movement = Input.GetAxis("Horizontal");
        Debug.Log(movement);

        if (movement > 0)
        {
            rigidbody.velocity = new Vector2(movement * speed, rigidbody.velocity.y);
            SoundManager.playsound("walk");
            

        }
        else if (movement < 0)
        {
            rigidbody.velocity = new Vector2(movement * speed, rigidbody.velocity.y);
            SoundManager.playsound("walk");
        }
        else
        {
            rigidbody.velocity = new Vector2(0, rigidbody.velocity.y);
        }
        if (Input.GetButtonDown("Jump"))
        {
            rigidbody.velocity = new Vector2(rigidbody.velocity.x, jumpspeed);
            SoundManager.playsound("jump");
        }
        movement = Input.GetAxis("Vertical");
        Debug.Log(movement);

        if (movement > 0)
        {
            rigidbody.velocity = new Vector2(movement * speed, rigidbody.velocity.x);
            SoundManager.playsound("walk");

        }
        else if (movement < 0)
        {
            rigidbody.velocity = new Vector2(movement * speed, rigidbody.velocity.x);
            SoundManager.playsound("walk");
        }
        else
        {
            rigidbody.velocity = new Vector2(0, rigidbody.velocity.x);
        }
        if (Input.GetButtonDown("Jump"))
        {
            rigidbody.velocity = new Vector2(rigidbody.velocity.y, jumpspeed);
            SoundManager.playsound("jump");
        }

    }
}
