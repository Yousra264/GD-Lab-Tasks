﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SoundManager : MonoBehaviour
{
    // Start is called before the first frame update
    public static AudioClip jumpsound, walksound;
    static AudioSource audiosrc;

    void Start()
    {
        jumpsound = Resources.Load<AudioClip>("jump");
        walksound = Resources.Load<AudioClip>("walk");
        audiosrc = GetComponent<AudioSource>();


    }

    // Update is called once per frame
    void Update()
    {

        
    }
    public static void playsound(string clip)
    {
        switch (clip)
        {
            case "jump":
                audiosrc.PlayOneShot(jumpsound);
                break;
            case "walk":
                audiosrc.PlayOneShot(walksound);
                break;
        }
    }
}
